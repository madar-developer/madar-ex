<html>

<head>
    <title> مدار اكسبريس | للشحن والتغليف</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" media="screen" href="https://fontlibrary.org/face/droid-arabic-kufi" type="text/css" />
    <link href="{{url('/assets/css/owl.carousel.css')}}" rel="stylesheet">
    <link href="{{url('/assets/css/bootstrap.css')}}" rel='stylesheet' type='text/css' />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css" rel='stylesheet'
        type='text/css' />
    <link href="{{url('/assets/css/style.css')}}" rel='stylesheet' type='text/css' />
    <link href="{{url('/assets/css/mt-style.css')}}" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
</head>

<body>

    <div id="loading-screen">
        <div class="lds-ripple">
            <div></div>
            <div></div>
        </div>
    </div>

    <div class="header-section">
        <!----- start-header---->
        <div id="home" class="header">
            <div class="container">
                <div class="top-header">
                    <div class="logo">
                        <a href="#">
                            <img src="{{url('/assets/images/logo.png')}}" title="logo" />
                        </a>
                    </div>
                    <!----start-top-nav---->
                    <nav class="top-nav">
                        <ul class="top-nav">
                            
                            <li class="page-scroll">
                                <a href="{{url('/')}}" class="">الرئيسية </a>
                            </li> 
                        </ul>
                        <a href="#" id="pull">
                            <img src="{{url('/assets/images/nav-icon.png')}}" title="menu" />
                        </a>
                    </nav>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
        <!----- //End-header---->
        <!----- //End-slider---->
        <div class="clearfix"></div>
    </div>
    <div id="fea" class="features">
        <div class="container">
            <div class="section-head text-center">
                <h3>
                    <span class="frist"></span>
                     انشاء حساب   <span class="second"></span>
                </h3>
            </div>
            <!----features-grids----->
            <div class="features-grids">
                <div class="col-md-12">
                    {!!Form::open( ['url' => route('company-register') ,'method' => 'Post','files' => true]) !!}
                    <div class="col-sm-12">
                        <div class="card-box">
                    
                            <div class="row">
                                <div class="col-lg-12">
                    
                                    @if ($errors->any())
                                    <div class="alert alert-danger">
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label class=""> اسم المتجر * </label>
                                                <div class="">
                                                    {!! Form::text("name",null,['class'=>'form-control', 'required' => ''])!!}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class=""> رقم الجوال * </label>
                                                <div class="">
                                                    {!! Form::text("phone",null,['class'=>'form-control', 'placeholder' => "",
                                                    'required' => ''])!!}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="">البريد الالكترونى <span>*</span></label>
                                                <div class="">
                                                    {!! Form::email("email",null,['class'=>'form-control',
                                                    'required' => '' ])!!}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="">كلمة المرور <span>*</span></label>
                                                <div class="">
                                                    {!! Form::password("password",['class'=>'form-control',
                                                    'required' => ''
                                                    ])!!}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class=""> تأكيد كلمه المرور <span></span></label>
                                                <div class="">
                                                    {!! Form::password("password_confirmation",['class'=>'form-control', 'required' => '' ])!!}
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label class="">المدينة *</label>
                                                <div class="">
                                                    {!! Form::select("city_id",TheCity(),null,['class'=>"form-control select2 ", "autocomplete"=>
                                                    'off', 'id' => 'banks', 'style' =>" display: inline-block;"])!!}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="">العنوان كامل *</label>
                                                <div class="">
                                                    {!! Form::text("adress_details",null,['class'=>"form-control select2 ", "autocomplete"=>
                                                    'off', 'id' => 'banks', 'style' =>" display: inline-block;"])!!}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class=""> السجل التجارى * </label>
                                                <div class="">
                                                    {!! Form::text("commercial_record",null,['class'=>'form-control', 'placeholder' => "",
                                                    'required' => ''])!!}
                                                </div>
                                            </div>
                    
                    
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <div class="clear-fix">
                    </div>
                    
                    <div class="card-box">
                        <div class="row">
                    
                    
                            <div class="clearfix"></div>
                    
                            <div class="text-center">
                                <button class="btn btn-warning waves-effect waves-light btn-submit" type="submit" style="font-size: 20px;"> انشاء حساب </button>
                                </br>
                                </br>
                            </div>
                        </div>
                    
                    </div>
                    </div>
                    
                {!!Form::close() !!}
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <!---728x90--->

        <div class="clearfix"></div>
    </div>







    <div id="download" class="footer">
        <div class="container">

            <div class="row">
                <div class="col-lg-3">
                    <h2> عن التطبيق </h2>
                    <a href="#"> <img style="margin-bottom: 15px;" src="{{url('/assets/images/logo-white.png')}}"> </a>
                    <p> مدار اكسبريس للشحن و التغليف في المملكة العربية السعودية </p>
                </div>
                <div class="col-lg-3">
                    <div class="links">
                        <h2> اهم الروابط </h2>
                        <ul class="footer-nav">
                            <li class="page-scroll">
                                <a href="#fea" class="scroll">مميزات التطبيق </a>
                            </li>
                            <li class="page-scroll">
                                <a href="#services" class="scroll"> خدماتنا </a>
                            </li>
                            <li class="page-scroll">
                                <a href="#clients" class="scroll"> عملائنا </a>
                            </li>
                            <li class="page-scroll">
                                <a href="#gallery" class="scroll"> صور من التطبيق </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3">
                    <h2>حمل التطبيق الأن </h2>
                    <div class="download text-center wow slideInUp">
                        <a
                            href="https://apps.apple.com/us/app/madar-express-%D9%85%D8%AF%D8%A7%D8%B1-%D8%A7%D9%83%D8%B3%D8%A8%D8%B1%D8%B3/id1321185983?ls=1">
                            <img src="{{url('/assets/images/apple-store-logo-png-7.png')}}"> </a>
                        <a href="https://play.google.com/store/apps/details?id=com.madarex2" target="_blank"> <img
                                src="{{url('/assets/images/google-play-store.png')}}"> </a>
                    </div>
                </div> <!-- col-lg-4 -->
                <div class="col-lg-3 contact">
                    <h2> تواصل معنا </h2>
                    <p> <i class="fa fa-phone"></i> 920020804 </p>
                    <p> <i class="fa fa-envelope"></i> info@madarex.sa</p>
                    <div class="icons">
                        <a class="" href="https://www.facebook.com/MadarExpress/" target="_blank">
                            <i class="fab fa-facebook"></i>
                        </a>
                        <a class="" href="https://www.youtube.com/watch?v=QoFk472vF-Y" target="_blank">
                            <i class="fab fa-youtube"></i>
                        </a>
                        <a class="" href="https://twitter.com/madar_ex" target="_blank">
                            <i class="fab fa-twitter"></i>
                        </a>
                    </div>
                </div>

            </div>

        </div>


    </div>

    <p class="copyright"> جميع الحقوق محفوظة - تصميم <a href="https://loc.sa/" target="_blank"> مدار الرياده لتقنيه المعلومات  </a> </p>
    <!---- start-smoth-scrolling---->
    <script src="{{url('/assets/js/jquery.min.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.1.1/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
    <script type="text/javascript" src="{{url('/assets/js/move-top.js')}}"></script>
    <script type="text/javascript" src="{{url('/assets/js/easing.js')}}"></script>
    <script src="{{url('/assets/js/owl.carousel.js')}}"></script>
    <script type="text/javascript">
        jQuery(document).ready(function ($) {
            $(".scroll").click(function (event) {
                event.preventDefault();
                $('html,body').animate({
                    scrollTop: $(this.hash).offset().top
                }, 1000);
            });
        });

    </script>
    <script>
        $(document).ready(function () {
            $("#owl-demo").owlCarousel({
                items: 3,
                lazyLoad: true,
                autoPlay: true
            });
        });

    </script>
    <script>
        $(document).ready(function () {
            $("#owl-demo2").owlCarousel({
                items: 5,
                lazyLoad: true,
                autoPlay: true,
                pagination: false,
            });
        });

    </script>
    <script>
        $(document).ready(function () {
            $("#loading-screen").fadeOut();
        });

    </script>
    <script>
        $(function () {
            var pull = $('#pull');
            menu = $('nav ul');
            menuHeight = menu.height();
            $(pull).on('click', function (e) {
                e.preventDefault();
                menu.slideToggle();
            });
            $(window).resize(function () {
                var w = $(window).width();
                if (w > 320 && menu.is(':hidden')) {
                    menu.removeAttr('style');
                }
            });
        });

    </script>
    <script>
        new WOW().init();

    </script>


    <script>
        $(document).ready(function () {
            // Add minus icon for collapse element which is open by default
            $(".collapse.in").each(function () {
                $(this)
                    .siblings(".panel-heading")
                    .find("span.fa")
                    .addClass("rotate");
            });

            // Toggle plus minus icon on show hide of collapse element
            $(".collapse")
                .on("show.bs.collapse", function () {
                    $(this)
                        .parent()
                        .find("span.fa")
                        .addClass("rotate");
                })
                .on("hide.bs.collapse", function () {
                    $(this)
                        .parent()
                        .find("span.fa")
                        .removeClass("rotate");
                });
        });
        //$(document).on('click', '#follow', function () {
            //var orderStatus = $('#orderStatus').val()
           // $.get('{{url("get-order-status")}}/' + orderStatus).done(function (data) {
              //  if (data['code'] == 200) {

                //    $('#order-response').html(`
               // <div class="col-lg-12 text-center">
                 //   <div class="one-state done">
                   //     <i class="fa fa-close-o">X</i>
                    //    <h4> ` + data['message'] + `</h4>
                   // </div>
                   // `);
               // } else {
                 //   $('#order-response').html(`
                // <div class="col-lg-12 text-center">
                 //   <div class="one-state done">
                      //  <i class="fa fa-check"></i>
                      //  <h4> ` + data['message'] + `</h4>
                   // </div>
                  //  `);
               // }
               // console.log(data);
           // });
      //  }); 

      $(document).on('click','#follow',function(){
            var orderStatus = $('#orderStatus').val()
            $.get('{{url("get-order-status")}}/'+orderStatus).done(function(data){
                if(data['code'] == 200)
                {

                    $('#order-response').html(data['html']);
                }else{
                    $('#order-response').html(data['message']);
                }
                console.log(data);
            });
          });






        /////////////////////////////contact message..re////////////////////////
        $(document).on('submit', '#contact-form', function (e) {
            e.preventDefault()
            var data = $(this).serialize();
            $.post( $(this).attr('action'), data ).done(function (data) {
                if (data['code'] == 200) {
                    $('#contact-message').show();
                    setTimeout(function(){
                        $('#contact-message').hide(); 
                    },5000);
                } else {
                    
                }
                console.log(data);
            });
        });

    </script>




</body>

</html>
