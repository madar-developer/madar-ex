<div class="card-box">

    <div class="row">
        <div class="col-lg-12">
            <p class="custom-label-centerd text-left"> معلومات المستلم </p>
        </div>
        <div class="col-lg-6">
            {{--  //////////////////////////////////////////  --}}
   
        
    
            <div class="form-group">
                <label class=""> اسم المستلم *</label>
                <div class=" append">
                    {!! Form::text("recipent_name",null,['class'=>'form-control select2','style' =>" display:
                    inline-block;"])!!}
                </div>
            </div>
            <div class="form-group">
                <label class=""> رقم الجوال : </label>
                <div class="">
                    {!! Form::text("phone",null,['class'=>'form-control', 'placeholder' => "",
                    'required' => ''])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
           
            
            <div class="form-group">
                <label class=""> العنوان كامل * </label>
                <div class="">
                    {!! Form::text("adress_details",null,['class'=>'form-control', 'placeholder' => "",
                    'required' => ''])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label class="">  ملحوظات * </label>
                <div class="">
                    {!! Form::text("notes",null,['class'=>'form-control', 'placeholder' => ""])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label class="">المدينه</label>
                <div class=" append">
                    {!! Form::select("city_id",TheCity(),null,['class'=>"form-control select2 ", "autocomplete"=>
                    'off'])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
           
            <div class="form-group">
                <label class="">الحاله</label>
                <div class=" append">
                    {!! Form::select("status",OrderStatus(),null,['class'=>"form-control select2 ", "autocomplete"=>
                    'off'])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label class="">رقم المرجع</label>
                <div class=" append">
                    {!! Form::text("refrence_no",null,['class'=>"form-control select2 ", "autocomplete"=>
                    'off'])!!}
                </div>
            </div>
        
         
        
        </div>

       
    </div>
</div>

<div class="card-box">
    <p class="custom-label-centerd text-left"> معلومات الشحن </p>
    <div class="row">
        <div class="col-lg-4">
            <div class="form-group">
                <label class=""> عدد الطرود * </label>
                <div class="">
                    {!! Form::number("packages_number",null,['class'=>'form-control', 'placeholder' => ""])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="form-group">
                <label class=""> السعر * </label>
                <div class="">
                    {!! Form::number("price",null,['class'=>'form-control', 'placeholder' => ""])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="form-group">
                <label class="">طريقه الدفع:</label>
                <div class=" append">
                    {!! Form::select("payment_method_id",PaymentMethod(),null,['class'=>"form-control select2 ",
                    "autocomplete"=> 'off'])!!}
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>





<div class="card-box">
    <div class="row">


        <p class="custom-label-centerd text-left">  معلومات الشاحن  </p>    

        <div class="col-lg-12"> 
            <div class="form-group">
                <label class=""> اختار المتجر  *</label>
                <div class=" append">
                    {!! Form::select("company_id",StoreOrCompany(),null,['class'=>"form-control select2 ",
                    "autocomplete"=> 'off' , 'required' => ''])!!}
                </div>
            </div>
        </div>


        {{-- <div class="text-center">
            <button class="btn btn-primary waves-effect waves-light btn-submit" type="submit">  اضافة </button>
        </div> --}}
    </div>

        
</div> 

<div class="card-box">
    <div class="row">


        <p class="custom-label-centerd text-left">  معلومات التوصيل  </p>    

        <div class="col-lg-12"> 
            <div class="form-group">
                <label class=""> تخصيص سائق التوصيل  *</label>
                <div class=" append">
                    {!! Form::select("driver_id",DriversList(),null,['class'=>"form-control select2 ",
                    "autocomplete"=> 'off' , ])!!}
                </div>
            </div>
        </div>


        <div class="text-center">
            <button class="btn btn-primary waves-effect waves-light btn-submit" type="submit">  اضافة </button>
        </div>
    </div>

        
</div> 



