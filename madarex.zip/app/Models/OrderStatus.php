<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderStatus extends Model
{
    protected $table='order_statuses';
    protected $fillable = [
        'key', 'name' , 'image' , 'details' , 'sort' , 'driver_active' , 'final_step' , 'color'
    ];
}
