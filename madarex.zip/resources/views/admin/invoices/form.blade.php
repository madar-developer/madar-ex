<!--     <h4 class="header-title header-title-custom m-t-0 m-b-30">بيانات الفاتورة</h4>-->


<div class="card-box">
    <div class="row">
        <div class="col-lg-12">
            <p class="custom-label-centerd text-left"> بيانات الاستلام </p>
        </div>
        <div class="col-lg-6">
            {{--  //////////////////////////////////////////  --}}




            <div class="form-group">
                <label class=""> اسم المستلم :</label>
                <div class=" append">
                    {!! Form::text("reciever_name",null,['class'=>'form-control select2','style' =>" display:
                    inline-block;"])!!}
                </div>
            </div>
            <div class="form-group">
                <label class=""> الهاتف : </label>
                <div class="">
                    {!! Form::text("reciever_phone",null,['class'=>'form-control', 'placeholder' => "",
                    'required' => ''])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">


            <div class="form-group">
                <label class=""> الجوال : </label>
                <div class="">
                    {!! Form::text("reciever_mobile",null,['class'=>'form-control', 'placeholder' => "",
                    'required' => ''])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label class=""> البريد الالكترونى : </label>
                <div class="">
                    {!! Form::text("reciever_email",null,['class'=>'form-control', 'placeholder' => "",
                    'required' => ''])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label class=""> الدوله :</label>
                <div class=" append">
                    {!! Form::text("reciever_city",null,['class'=>"form-control select2 ", "autocomplete"=>
                    'off'])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">

            <div class="form-group">
                <label class=""> المدينه :</label>
                <div class=" append">
                    {!! Form::text("reciever_country",null,['class'=>"form-control select2 ", "autocomplete"=>
                    'off'])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label class=""> العنوان :</label>
                <div class=" append">
                    {!! Form::text("reciever_address",null,['class'=>"form-control select2 ", "autocomplete"=>
                    'off'])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label class=""> التوقيع :</label>
                <div class=" append">
                    {!! Form::text("reciever_signature",null,['class'=>"form-control select2 ", "autocomplete"=>
                    'off'])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label class=""> التاريخ :</label>
                <div class=" append">
                    {!! Form::text("reciever_date",null,['class'=>"form-control select2 datepicker ", "autocomplete"=>
                    'off'])!!}
                </div>
            </div>
            <div class="form-group">
                <label class=""> التاريخ    * (هجري)</label>
                <div class=" append">
                    {!! Form::text("reciever_date_hijri",null,['class'=>"form-control  hijri-date-input", "autocomplete"=> 'off', 'id' => 'banks', 'style' =>"width: 100%; display: inline-block;"])!!}
                </div>
            </div>
        </div>
       
        <div class="col-lg-6">
            <div class="form-group">
                <label class=""> اسم المندوب :</label>
                <div class=" append">
                    {!! Form::text("reciever_delegate",null,['class'=>"form-control select2 ", "autocomplete"=>
                    'off'])!!}
                </div>
            </div>
        </div>


    </div>
</div>
<div class="card-box">
    <div class="row">
        <div class="col-lg-12">
            <p class="custom-label-centerd text-left"> بيانات الارسال </p>
        </div>
        <div class="col-lg-6">
            {{--  //////////////////////////////////////////  --}}



            <div class="form-group">
                <label class="">اسم المرسل :</label>
                <div class=" append">
                    {!! Form::text("sender_name",null,['class'=>'form-control select2','style' =>" display:
                    inline-block;"])!!}
                </div>
            </div>
            <div class="form-group">
                <label class=""> الهاتف : </label>
                <div class="">
                    {!! Form::text("sender_phone",null,['class'=>'form-control', 'placeholder' => "",
                    'required' => ''])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">


            <div class="form-group">
                <label class="">الجوال : </label>
                <div class="">
                    {!! Form::text("sender_mobile",null,['class'=>'form-control', 'placeholder' => "",
                    'required' => ''])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label class="">البريد الالكترونى : </label>
                <div class="">
                    {!! Form::text("sender_mail",null,['class'=>'form-control', 'placeholder' => "",
                    'required' => ''])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label class="">الدوله :</label>
                <div class=" append">
                    {!! Form::text("sender_city",null,['class'=>"form-control select2 ", "autocomplete"=>
                    'off'])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">

            <div class="form-group">
                <label class="">المدينه :</label>
                <div class=" append">
                    {!! Form::text("sender_country",null,['class'=>"form-control select2 ", "autocomplete"=>
                    'off'])!!}
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="form-group">
                <label class="">العنوان :</label>
                <div class=" append">
                    {!! Form::text("sender_address",null,['class'=>"form-control select2 ", "autocomplete"=>
                    'off'])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label class="">التوقيع :</label>
                <div class=" append">
                    {!! Form::text("sender_signature",null,['class'=>"form-control select2 ", "autocomplete"=>
                    'off'])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label class="">التاريخ :</label>
                <div class=" append">
                    {!! Form::text("sender_date",null,['class'=>"form-control select2 datepicker", "autocomplete"=>
                    'off'])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label class="">اسم المندوب :</label>
                <div class=" append">
                    {!! Form::text("sender_delegate",null,['class'=>"form-control select2 ", "autocomplete"=>
                    'off'])!!}
                </div>
            </div>
        </div>

    </div>
</div>
<div class="card-box">
    <p class="custom-label-centerd text-left"> بيانات الطلب </p>
    <div class="row">
        <div class="col-lg-4">
            <div class="form-group">
                <label class=""> رقم الطلب : </label>
                <div class="">
                    {!! Form::select("order_id",Order(),null,['class'=>'form-control', 'placeholder' => ""])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="form-group">
                <label class=""> عدد الطرود : </label>
                <div class="">
                    {!! Form::number("packages_number",null,['class'=>'form-control', 'placeholder' => ""])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="form-group">
                <label class=""> نوع الشحنه :</label>
                <div class=" append">
                    {!! Form::text("Shipment_type",null,['class'=>"form-control select2 ",
                    "autocomplete"=> 'off'])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="form-group">
                <label class="">  المبلغ الكلى :</label>
                <div class=" append">
                    {!! Form::text("total_price",null,['class'=>"form-control select2 ",
                    "autocomplete"=> 'off'])!!}
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="form-group">
                <label class=""> محتوى الشحنه : </label>
                <div class="">
                    {!! Form::textarea("Shipment_content",null,['class'=>'form-control', 'placeholder' => ""])!!}
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>

<div class="col-lg-12">
    <div class="panel-footer">
        <div class="clearfix">
            <div class="col-md-12 col-md-offset-5">
                <button type="submit" class="btn blue">
                    <i class="fa fa-check"></i>
                    حفظ
                </button>
                <a href="{{url('/dashboard/shops')}}" class="btn default cancel-button-panel">
                    <i class="fa fa-times"></i>
                    إلغاء الأمر
                </a>
            </div>
        </div>
    </div>
</div>


</div>
