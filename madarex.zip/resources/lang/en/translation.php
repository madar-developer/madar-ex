<?php

return [

    'permission' => [
        'car' => 'السيارات',
        'car_maintenance' => 'صيانه السيارات',
        'company' => 'الشركات',
        'order' => 'الطلبات',
        'driver' => 'السائقين',
        'user' => 'المستخدمين',
    ],

];
