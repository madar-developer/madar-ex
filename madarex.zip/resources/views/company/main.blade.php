@extends('company.layout.app')
@section('style')

<script src="{{ asset('/adminto/assets/js/modernizr.min.js')}}"></script>
@endsection
@section('content')

<div class="row">

   



    <div class="col-lg-3 col-md-6">
        <div class="card-box" style="background-color: #c2daf4;">


            <h4 class="header-title m-t-0 m-b-30">عدد  orders</h4>

            <div class="widget-chart-1">
                <div class="widget-chart-box-1">
                    <i class="fa fa-building-o" aria-hidden="true"></i>
                </div>
                <div class="widget-detail-1">
                    <h2 class="p-t-10 m-b-0">  {{\App\Models\Order::where('company_id', auth('company')->id())->count()}} </h2>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="card-box" style="background-color: #c2daf4;">


            <h4 class="header-title m-t-0 m-b-30">عدد  الفواتير</h4>

            <div class="widget-chart-1">
                <div class="widget-chart-box-1">
                    <i class="fa fa-building-o" aria-hidden="true"></i>
                </div>
                <div class="widget-detail-1">
                    <h2 class="p-t-10 m-b-0">  {{\App\Models\Invoice::whereHas('Order', function($q){$q->where('company_id', auth('company')->id());})->count()}} </h2>
                </div>
            </div>
        </div>
    </div>
    @foreach (\App\Models\OrderStatus::whereIn('key', ['at_office', 'delivered'])->get() as $item)

    <div class="col-lg-3 col-md-6">
        <div class="card-box" style="background-color: {{$item->color}};">


            <h4 class="header-title m-t-0 m-b-30" style="color: #000;"> الطلبات {{$item->name}}</h4>

            <div class="widget-chart-1">
                <div class="widget-chart-box-1">
                    <i class="fa fa-building-o" aria-hidden="true"></i>
                </div>
                <div class="widget-detail-1">
                    <h2 class="p-t-10 m-b-0" style="color: #000;">
                        {{\App\Models\Order::where('company_id', auth('company')->id())->where('status','=',$item->key)->count()}} </h2>
                    <a href="{{url('/dashboard/orders?status='.$item->key)}}">
                        <p class="text-muted"> {{$item->name}} </p>
                    </a>
                </div>
            </div>
        </div>
    </div>
    @endforeach
    <div class="col-lg-3 col-md-6">
        <div class="card-box widget-user">
            <div>
                <div class="wid-u-info">
                    <h4 class="m-t-0 m-b-5"><a href="{{route('company.company-finance.pdf')}}">  تحميل تقرير مالي </a></h4>
                </div>
            </div>
        </div>
    </div><!-- end col -->
</div>
<!-- end row -->






@if(false)
<div class="row">
    <div class="col-lg-3 col-md-6">
        <div class="card-box widget-user">
            <div>
                <div class="box-icon">
                    <i class="fa fa-plus-circle" aria-hidden="true"></i>
                </div>
                <div class="wid-u-info">
                    <h4 class="m-t-0 m-b-5"><a href="{{url('/dashboard/users/create')}}"> إضافه عميل </a></h4>
                </div>
            </div>
        </div>
    </div><!-- end col -->
    <div class="col-lg-3 col-md-6">
        <div class="card-box widget-user">
            <div>
                <div class="box-icon">
                    <i class="fa fa-plus-circle" aria-hidden="true"></i>
                </div>
                <div class="wid-u-info">
                    <h4 class="m-t-0 m-b-5"><a href="{{url('/dashboard/drivers/create')}}"> إضافه سائق </a></h4>
                </div>
            </div>
        </div>
    </div><!-- end col -->

    <div class="col-lg-3 col-md-6">
        <div class="card-box widget-user">
            <div>
                <div class="box-icon">
                    <i class="zmdi zmdi-notifications-none" aria-hidden="true"></i>
                </div>
                <div class="wid-u-info">
                    <h4 class="m-t-0 m-b-5"><a href="{{url('/dashboard/notifications')}}">ارسال اشعار </a></h4>
                </div>
            </div>
        </div>
    </div><!-- end col -->
</div>
<!-- end row -->

<div class="row">
    <div class="col-lg-4">
        <div class="card-box">
            <h4 class="header-title m-t-0">العملاء على التطبيق</h4>
            <div id="morris-bar-example" style="height: 280px;"></div>
        </div>
    </div><!-- end col -->

    <div class="col-lg-4">
        <div class="card-box">
            <h4 class="header-title m-t-0">الطلبات بالشهر </h4>
            <div id="morris-line-example" style="height: 280px;"></div>
        </div>
    </div><!-- end col -->

</div>
<!-- end row -->


@endif


@endsection
@section('script')


@endsection
