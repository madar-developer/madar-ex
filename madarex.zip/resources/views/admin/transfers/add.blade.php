@extends('admin.layout.app')
@section('style')
<link href="{{ asset('/adminto/assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')}}"  rel="stylesheet">
<link href="{{ asset('/adminto/assets/plugins/bootstrap-daterangepicker/daterangepicker.css')}}" rel="stylesheet" >
<link href="{{ asset('/adminto/assets/plugins/timepicker/bootstrap-timepicker.min.css')}}" rel="stylesheet">
@endsection
@section('content')
<div class="row">
    {{--  //////////////////////////////////  --}}
                {!!Form::open( ['url' => '/dashboard/transfers/' ,'method' => 'Post','files' => true]) !!}
                @include('admin.transfers.form')
                {!!Form::close() !!}
</div>
<!-- end row -->

@endsection
@section('script')
    <script src="{{ asset('/adminto/assets/plugins/moment/moment.js')}}"></script>
    <script src="{{ asset('/adminto/assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')}}"></script>
         <script src="{{ asset('/adminto/assets/plugins/bootstrap-daterangepicker/daterangepicker.js')}}"></script>
         <script src="{{ asset('/adminto/assets/plugins/timepicker/bootstrap-timepicker.min.js')}}"></script>
<script>
    // Date Picker
jQuery('.datepicker').datepicker({
    format: "yyyy-mm-dd"
});
{{-- jQuery('.timepicker2').timepicker({
    showMeridian : false
});
jQuery('.timepicker3').timepicker({
    minuteStep : 15
}); --}}
$(document).on('click', '.load-bills', function(){
    var companyId = $('#company_id').val();
    var dateFrom = $('#date_from').val();
    var dateTo = $('#date_to').val();
    //alert(1);
    var url = "{{url('dashboard/show_invoices')}}";
    $.get(url+'?company_id='+companyId +'&date_from='+dateFrom +'&date_to='+dateTo )
    .done(function(res){
        console.log(res);
        $('#ajax-content').html(res);
        {{--    --}}
    })
    .fail(function(error){});
});
</script>
@endsection