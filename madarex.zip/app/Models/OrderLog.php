<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderLog extends Model
{
    protected $table='order_logs';
    protected $fillable = [
        'order_id', 'status' , 'details', 'created_at'
    ];
    public function Order()
    {
        return $this->belongsTo(Order::class, 'order_id');
    }
}
