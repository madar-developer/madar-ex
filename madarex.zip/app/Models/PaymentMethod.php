<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentMethod extends Model
{
    protected $table='payment_methods';
    protected $fillable = [
        'name', 
    ];

    public function Order()
    {
        return $this->Hasmany(Order::class, 'payment_method_id');
    }
}
