<!-- ========== Left Sidebar Start ========== -->
            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">

                    <!-- User -->
                    <div class="user-box">
                        <div class="user-img">
                            <img src="{{getImage(auth()->User()->image)}}" alt="user-img" title="Mat Helme" class="img-circle img-thumbnail img-responsive" style="    height: 88px;
                            width: 97px;">
                            <div class="user-status offline"><i class="zmdi zmdi-dot-circle"></i></div>
                        </div>
                        <h5><a href="{{url('company/settings/admins-edit')}}">  {{ auth()->user()->name }} </a> </h5>
                        <ul class="list-inline">

                            {{--  <li>
                                <a href="#" class="text-custom">
                                    <i class="zmdi zmdi-power"></i>
                                    <span> تسجيل خروج </span>
                                </a>
                            </li>  --}}
                            <li>  <a href="{{ route('logout') }}"
                                onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();" class="text-custom">
                                    <i class="zmdi zmdi-power"></i>
                               <span ></span> تسجيل الخروج
                           </a>
                           <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                               {{ csrf_field() }}
                               <input type="hidden" name="company" value="1">
                           </form>
                       </li>
                        </ul>
                    </div>
                    <!-- End User -->

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <ul>
                            <li class="has_sub">
                                <a href="{{ url('/company') }}" class="waves-effect"><i class="zmdi zmdi-view-list"></i> <span> الرئيسيه  </span> <span class="menu-arrow"></span></a>
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="zmdi zmdi-view-list"></i> <span> الطلبات  </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="{{url('/company/company-orders')}}"> عرض  الطلبات </a></li>
                                    <li><a href="{{ url('/company/company-orders/create') }}">  اضافة طلب</a></li>
                                </ul>
                            </li>
                            <li class="has_sub">
                                <a href="{{ url('/company/company-invoices/') }}" class="waves-effect"><i class="zmdi zmdi-view-list"></i> <span> الفواتير  </span> </a>
                                
                            </li>
                            <li class="has_sub">
                                <a href="{{ url('/company/company-transfers/') }}" class="waves-effect"><i class="zmdi zmdi-view-list"></i> <span> الحولات  </span> </a>
                                
                            </li>

                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                </div>

            </div>
            <!-- Left Sidebar End -->