<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DriverFianance extends Model
{
    protected $table='driver_fianances';
    protected $fillable = [
        'branch_id', 'driver_id', 'total_amount' , 'driver_amount' , 'net_profit' ,
        'orders' , 'status' , 'verified'
    ];

    public function Admin()
    {
        return $this->belongsto(Admin::class, 'branch_id');
    }
    public function Driver()
    {
        return $this->belongsto(Driver::class, 'driver_id');
    }
}
