<?php
namespace App\Traits\Admin;

use Illuminate\Http\Request;
use App\Models\Slider;
use DB;

trait SliderOperations
{
  

    /**
     * Register a New .
     *
     * @param $request
     * @return \App\
     */
    public function register ($request)
    {
        $data = $request->all();
        if ($request->hasFile('image')) {
            $data['image'] = uploadFile($request);
        }
        DB::beginTransaction();
        $Slider = Slider::create($data);
        DB::commit();
        return $Slider;
    }


    /**
     * Update Record
     * @param $truck
     * @param $request
     */
    public function UpdateRecords(Slider $Slider,$request)
    {
        $data = $request->all();
        if ($request->hasFile('image')) {
            @unlink(public_path('/cdn/'.$Slider->image));
            // 
            $data['image'] = uploadFile($request);
        }
        $Slider->update($data);
        return $Slider;
    }

    /**
     * delete Record
     * @param $truck
     * @param $request
     */
    public function DeleteRecord($id)
    {
        //
    }
}