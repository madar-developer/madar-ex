
<div class="row">
   
    <div class="col-lg-12 text-center" >
        الرقم الطلب: {{$order->refrence_no}}
        <br />
        رقم التتبع: {{$order->serial}}
    </div>
    @foreach(OrderStatus() as $key => $value)
    @php
    //////////////////////////////
    if($order->status != $key) continue;
    @endphp
    @if($order->status == $key)
    
    <div class="col-lg-12" style="text-center">
        <div class="one-state {{$class}}">
            {{--  <img style="width: 60px;" src="https://image.flaticon.com/icons/svg/984/984233.svg">  --}}
           
            <img style="width: 60px;" src="{{url('/adminto/assets/images/icon02.png')}}">
            <h4> {{$value}} </h4>
        </div>
    </div>
    @php
    $class= "to-do";
    @endphp
    @else
    <div class="col-lg-4">
        <div class="one-state {{$class}}">
            <i class="fa fa-check"></i>
            <h4> {{$value}} </h4>
        </div>
    </div>
    
    @endif
    @endforeach

    <br />
    <br />
    <br />
    {{--  <div class="col-md-12 text-right" style="background-color:#fff; margin-top:  70px;">  --}}
        <div class="col-md-12 text-right" style=" margin-top:  70px;">
      
        <table class="table table-bordered" style=" border: 1px solid black;">
            <thead>
                <tr style=" border: 1px solid black;">
                    <th style="text-align:right; border: 1px solid black;" >التاريخ</th>
                    <th style="text-align:right; border: 1px solid black;">الحالة</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($order->OrderLog()->get() as $item)
                <tr style=" border: 1px solid black;">
                    <td style=" border: 1px solid black;">{{$item->created_at->toDateString()}}</td>
                    <td style=" border: 1px solid black;">{{$item->details}}</td>
                </tr>
                @endforeach
                
            </tbody>
        </table>
        <table class="table table-bordered" style=" border: 1px solid black;">
            <thead>
                <tr style=" border: 1px solid black;">
                    <th style="text-align:right; border: 1px solid black;">اسم التاجر</th>
                    <th style="text-align:right; border: 1px solid black;">عدد الطرود</th>
                    <th style="text-align:right; border: 1px solid black;">المدينه </th>
                </tr>
            </thead>
            <tbody>
                <tr style=" border: 1px solid black;">
                    <td style=" border: 1px solid black;">{{$order->Company->name ?? ''}}</td>
                    <td style=" border: 1px solid black;">{{$order->packages_number}}</td>
                    <td style=" border: 1px solid black;">{{ $order->City->name ?? '' }}</td>
                </tr>

            </tbody>
        </table>
    </div>

</div>
