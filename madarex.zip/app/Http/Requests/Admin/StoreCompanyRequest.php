<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class StoreCompanyRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            // 'name'          => 'required|max:255',
            // 'email'         => 'required|email|unique:companies|max:255',
            // 'phone'         => 'required|unique:companies|max:255',
            // 'password'      => 'required|confirmed|max:255|min:6',
            // 'image'         => 'nullable|image',
        ];
    }
}
