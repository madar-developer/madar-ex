@extends('company.layout.app')
@section('style')
@section('header')
<li>
    <div class="add-btn">
        <a href="{{ url('/company/company-orders/create') }}" type="button"
            class="btn btn-custom btn-rounded waves-effect waves-light w-md m-b-5"> <i class="fa fa-check"></i> اضافة
        </a>
    </div>
</li>
@endsection
@endsection
@section('content')


<!-- Page-Title -->

<div class="row">

    <div class="col-sm-12">
        <div class="card-box">
            <form action="" method="get">
                <div class="row">
                    <div class="col-md-12 part-top">
                        <div class="row">

                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="row">



        <div class="col-lg-2">
            <div class="form-horizontal">
                <div class="form-group">
                    <div class="col-md-12">
                        <input type="text" name="serial_from"
                            value="{{(array_key_exists('serial_from', $search))? $search['serial_from'] : ''}}"
                            class="form-control" placeholder="  رقم الطلب من">
                    </div>
                </div>

            </div>
        </div>
        <div class="col-lg-2">
            <div class="form-horizontal">
                <div class="form-group">
                    <div class="col-md-12">
                        <input type="text" name="serial_to"
                            value="{{(array_key_exists('serial_to', $search))? $search['serial_to'] : ''}}"
                            class="form-control" placeholder="  رقم الطلب الي">
                    </div>
                </div>

            </div>
        </div>

        <div class="col-lg-2">
            <div class="form-horizontal">
                <div class="form-group">
                    <div class="col-md-12">
                        <input type="text" name="refrence_no"
                            value="{{(array_key_exists('refrence_no', $search))? $search['refrence_no'] : ''}}"
                            class="form-control" placeholder="رقم الطلب على متجر التاجر">
                    </div>
                </div>

            </div>
        </div>
        <div class="col-lg-2">
            <div class="form-horizontal">
                <div class="form-group">
                    <div class="col-md-12">
                        <input type="text" name="company_phone"
                            value="{{(array_key_exists('company_phone', $search))? $search['company_phone'] : ''}}"
                            class="form-control" placeholder="  رقم تليفون المتجر">
                    </div>
                </div>

            </div>
        </div>

        <div class="col-lg-2">
            <div class="form-horizontal">
                <div class="form-group">
                    <div class="col-md-12">
                        <input type="text" name="recipent_name"
                            value="{{(array_key_exists('recipent_name', $search))? $search['recipent_name'] : ''}}"
                            class="form-control" placeholder="اسم المستلم">
                    </div>
                </div>

            </div>
        </div>
        <div class="col-lg-2">
            <div class="form-horizontal">
                <div class="form-group">
                    <div class="col-md-12">
                        <input type="text" name="phone"
                            value="{{(array_key_exists('phone', $search))? $search['phone'] : ''}}" class="form-control"
                            placeholder="رقم تليفون المستلم">

                    </div>
                </div>

            </div>
        </div>

        <div class="col-lg-2">
            <div class="form-horizontal">
                <div class="form-group">
                    <div class="col-md-12">
                        {!! Form::select("status",array_merge(['' => 'اختر
                        الحالة'],OrderStatus()),(array_key_exists('status', $search))? $search['status'] :
                        null,['class'=>"form-control select2 "])!!}
                    </div>
                </div>

            </div>
        </div>

        <div class="col-md-1">
            <div class="form-horizontal m-b-15">
                <button type="button" onclick="$(this).closest('form').find('#excel').remove(); $(this).closest('form').submit();" class="btn btn-block btn-sm btn-success waves-effect waves-light b-t-10 b-b-10"><i class="fa fa-search"></i> بحث</button>
            </div>
        </div>
        <div class="col-md-1">
            <div class="form-horizontal">
                <button type="button" target="_blank" onclick="$(this).closest('form').prepend(`<input name='excel' id='excel' type='hidden' value='1' />`); $(this).closest('form').submit();" class="btn btn-block btn-sm btn-success waves-effect waves-light b-t-10 b-b-10">تصدير لExcel</button>
         
            </div>
        </div>

        <div class="col-md-2">
            <div class="form-horizontal">
                <a href="{{url('/company/company-orders')}}"
                    class="btn btn-block btn-sm btn-success waves-effect waves-light b-t-10 b-b-10"><i
                        class="fa fa-trash"></i> مسح خيارات البحث</a>
            </div>
        </div>

    </div>
</div>
</div>
</form>
</div>
</div>
</div>

<div class="row">

    <div class="col-sm-12">
        <div class="card-box text-left">
            <div class="row">

                <div class="col-lg-12">
                    <div class="box-tebal">

                        <div role="tabpanel" class="tab-pane " style="overflow-x: scroll;">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    @php
                                    $i = 1;
                                    @endphp
                                    <tr>

                                        <th>
                                            <input type="checkbox" class="ids" id="checkAll">
                                        </th>
                                        {{--  <th>IDs </th>  --}}
                                        <th> اسم المتجر </th>
                                        <th> رقم تليفون المتجر </th>
                                        <th> اسم المستلم </th>
                                        <th> رقم الجوال</th>

                                        <th> المدينه </th>
                                        <th> العنوان بالتفصيل </th>
                                        <th> عدد الطرود </th>
                                        <th> السعر</th>
                                        <th> طريقه الدفع </th>
                                        <th> اسم السائق </th>
                                        <th> السياره </th>
                                        {{--  <th>   ملحوظات </th>  --}}
                                        <th> الحالة </th>
                                        <th> رقم المرجع </th>
                                        <th> رقم التسلسل </th>
                                        <th> تاريخ الانشاء</th>


                                    </tr>
                                </thead>

                                <tbody>
                                    @foreach($orders as $item)

                                <tr style="background-color: {{$item->OrderStatus->color ?? ''}} !important;">
                                        <td>
                                            <input type="checkbox" name="ids[]" value="{{$item->id}}" class="ids"/>
                                            {{$i++}}
                                        </td>
                                        <td>{{$item->Company->name ?? ''}} </td>
                                        <td>{{$item->Company->phone ?? ''}} </td>
                                        <td>{{$item->recipent_name}} </td>
                                        <td>{{$item->phone}} </td>
                                        <td> {{ $item->City->name ?? '' }}</td>
                                        <td>{{$item->adress_details}} </td>
                                        <td>{{$item->packages_number}} </td>
                                        <td>{{$item->price}}</td>
                                        <td>{{$item->PaymentMethod->name ?? '' }}</td>
                                        <td>{{$item->Driver->first_name ?? ''  }}</td>
                                        <td>{{$item->Car->name ?? ''  }}</td>
                                        
                                        {{--  <td>{{$item->notes}}</td> --}}
                                        <td>
                                            {{__('words.'.$item->status)}}
                                        </td>
                                        <td>{{$item->refrence_no}}</td>
                                        <td>{{$item->serial}}</td>
                                        <td>{{$item->created_at}}</td>



                                    </tr>
                                    @endforeach




                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div><!-- end col -->
</div>
<!-- end row -->
<div class="col-sm-12">
    {{ $orders->appends($search)->links() }}
</div>


@endsection
@section('script')

@endsection
