<?php

return \App\Models\OrderStatus::orderBy('sort','asc')->pluck('name', 'key')->toArray();
